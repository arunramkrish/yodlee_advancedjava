package com.yodlee.advjava.jdbc.dao;

import java.io.IOException;
import java.util.Properties;

public class DbConfig {
	private String url;
	private String userName;
	private String password;
	private String driverClassName;
	private String customerDaoClassName;
	
	private static String jdbcConfigFileName = "jdbc.properties";
	private static DbConfig instance = new DbConfig();
			
	private DbConfig() {
		init();
	}
	
	public void init() {
		init(jdbcConfigFileName);
	}
	
	public void init(String configFile) {
		Properties props = new Properties();
		try {
			props.load(ClassLoader.getSystemClassLoader().getResourceAsStream(configFile));
		} catch (IOException e) {
			e.printStackTrace();
		}
		url = props.getProperty("url");
		userName = props.getProperty("userName");
		password = props.getProperty("password");
		driverClassName = props.getProperty("driverClassName");
		customerDaoClassName = props.getProperty("customerDaoClassName");
	}
	
	public static DbConfig getInstance() {
		return instance;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDriverClassName() {
		return driverClassName;
	}

	public void setDriverClassName(String driverClassName) {
		this.driverClassName = driverClassName;
	}

	public String getCustomerDaoClassName() {
		return customerDaoClassName;
	}

	public void setCustomerDaoClassName(String customerDaoClassName) {
		this.customerDaoClassName = customerDaoClassName;
	}
}
