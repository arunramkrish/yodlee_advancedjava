package com.yodlee.advjava.jdbc.client;

import java.util.Date;
import java.util.List;

import com.yodlee.advjava.jdbc.dao.CustomerDao;
import com.yodlee.advjava.jdbc.dao.DataAccessException;
import com.yodlee.advjava.jdbc.dao.DbConfig;
import com.yodlee.advjava.jdbc.model.Customer;

public class JdbcSimpleDemo {

	public JdbcSimpleDemo() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		try {
			CustomerDao dao = (CustomerDao)Class.forName(DbConfig.getInstance().getCustomerDaoClassName()).newInstance();
			dao.init();
			
			Customer c = new Customer(1L, "C1",  new Date(), "Addr1");
			dao.create(c);
			
			c = new Customer(2L, "C2",  new Date(), "Addr1");
			dao.create(c);
			
			c = new Customer(3L, "C3",  new Date(), "Addr1");
			dao.create(c);
			
			c = new Customer(4L, "C4",  new Date(), "Addr1");
			dao.create(c);
			
			List<Customer> customers = dao.findAll();
			for (Customer cus : customers) {
				System.out.println(cus);
			}
			
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DataAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
