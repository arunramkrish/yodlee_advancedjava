package com.yodlee.advjava.jdbc.dao;

import java.util.List;

import com.yodlee.advjava.jdbc.model.Customer;

public interface CustomerDao {
	void init() throws DataAccessException;
	
	void create(Customer c) throws DataAccessException;

	Customer findById(Long id) throws DataAccessException;

	List<Customer> findAll() throws DataAccessException;

	void delete(Long id) throws DataAccessException;
	
	void update(Customer c) throws DataAccessException;
}
