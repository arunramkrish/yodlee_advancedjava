package com.yodlee.advjava.jdbc.model;

import java.util.Date;

public class Customer {
	private Long id;
	private String name;
	private Date dob;
	private String contactDetails;
	
	public Customer() {
		super();
	}
	public Customer(Long id, String name, Date dob, String contactDetails) {
		super();
		this.id = id;
		this.name = name;
		this.dob = dob;
		this.contactDetails = contactDetails;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getContactDetails() {
		return contactDetails;
	}
	public void setContactDetails(String contactDetails) {
		this.contactDetails = contactDetails;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", dob=" + dob
				+ ", contactDetails=" + contactDetails + "]";
	}	
}	
