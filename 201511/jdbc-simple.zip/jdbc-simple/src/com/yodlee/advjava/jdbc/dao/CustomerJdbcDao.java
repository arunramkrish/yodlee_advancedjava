package com.yodlee.advjava.jdbc.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.yodlee.advjava.jdbc.model.Customer;

public class CustomerJdbcDao implements CustomerDao {

	public CustomerJdbcDao() {
		try {
			Class.forName(DbConfig.getInstance().getDriverClassName());
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void init() throws DataAccessException {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			DbConfig dbconfig = DbConfig.getInstance();
			conn = getConnection(dbconfig);

			stmt = conn.createStatement();
			rs = stmt.executeQuery("SELECT * FROM   INFORMATION_SCHEMA.TABLES "
					+ "WHERE LCASE(TABLE_NAME) = 'customers'");

			if (!rs.next()) {
				// table doesn't exist, so create table
				int rowsAffected = stmt
						.executeUpdate("create table customers (id bigint primary key, name varchar(100), "
								+ "dob date, contact_details varchar(250))");
				System.out.println("Table Customers created successfully "
						+ rowsAffected);
			}

		} catch (SQLException e) {
			throw new DataAccessException("Error " + e.getMessage(), e);
		} finally {
			releaseResources(conn, stmt, rs);
		}

	}

	private Connection getConnection(DbConfig dbconfig) throws SQLException {
		return DriverManager.getConnection(dbconfig.getUrl(),
				dbconfig.getUserName(), dbconfig.getPassword());
	}

	private void releaseResources(Connection conn, Statement stmt, ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public void create(Customer c) throws DataAccessException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			DbConfig dbconfig = DbConfig.getInstance();
			conn = getConnection(dbconfig);

			stmt = conn.prepareStatement("INSERT INTO CUSTOMERS(ID, NAME, DOB, CONTACT_DETAILS) VALUES ( ?, ?, ?, ?)");
			stmt.setLong(1, c.getId());
			stmt.setString(2, c.getName());
			stmt.setDate(3, new Date(c.getDob().getTime()));
			stmt.setString(4, c.getContactDetails());
			
			int count = stmt.executeUpdate();
			
			if (count == 1) {
				System.out.println("Customer record inserted successfully");
			}
		} catch (SQLException e) {
			throw new DataAccessException("Error " + e.getMessage(), e);
		} finally {
			releaseResources(conn, stmt, rs);
		}

	}

	@Override
	public Customer findById(Long id) throws DataAccessException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			DbConfig dbconfig = DbConfig.getInstance();
			conn = getConnection(dbconfig);

			stmt = conn.prepareStatement("SELECT ID, NAME, DOB, CONTACT_DETAILS FROM CUSTOMERS where ID = ?");
			stmt.setLong(1, id);
			
			rs = stmt.executeQuery();
			
			if (rs.next()) {
				String name = rs.getString("NAME");
				java.util.Date dob = new java.util.Date(rs.getDate("DOB").getTime());
				String contactDetails = rs.getString("CONTACT_DETAILS");
				
				Customer c = new Customer(id, name, dob, contactDetails);
				return c;
			} else {
				return null;
			}
		} catch (SQLException e) {
			throw new DataAccessException("Error " + e.getMessage(), e);
		} finally {
			releaseResources(conn, stmt, rs);
		}

	}

	@Override
	public List<Customer> findAll() throws DataAccessException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			DbConfig dbconfig = DbConfig.getInstance();
			conn = getConnection(dbconfig);

			stmt = conn.prepareStatement("SELECT ID, NAME, DOB, CONTACT_DETAILS FROM CUSTOMERS");
			
			rs = stmt.executeQuery();
			List<Customer> customers = new ArrayList<Customer>();
			while (rs.next()) {
				Long id = rs.getLong("ID");
				String name = rs.getString("NAME");
				java.util.Date dob = new java.util.Date(rs.getDate("DOB").getTime());
				String contactDetails = rs.getString("CONTACT_DETAILS");
				
				Customer c = new Customer(id, name, dob, contactDetails);
				
				customers.add(c);
			}
			return customers;
		} catch (SQLException e) {
			throw new DataAccessException("Error " + e.getMessage(), e);
		} finally {
			releaseResources(conn, stmt, rs);
		}

	}

	@Override
	public void delete(Long id) throws DataAccessException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			DbConfig dbconfig = DbConfig.getInstance();
			conn = getConnection(dbconfig);

			stmt = conn.prepareStatement("DELETE FROM CUSTOMERS where ID = ?");
			stmt.setLong(1, id);
			
			stmt.executeUpdate();
		} catch (SQLException e) {
			throw new DataAccessException("Error " + e.getMessage(), e);
		} finally {
			releaseResources(conn, stmt, rs);
		}


	}

	@Override
	public void update(Customer c) throws DataAccessException {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			DbConfig dbconfig = DbConfig.getInstance();
			conn = getConnection(dbconfig);

			stmt = conn.prepareStatement("UPDATE CUSTOMERS SET NAME = ?, DOB = ?, CONTACT_DETAILS = ? WHERE ID = ?");
			stmt.setLong(4, c.getId());
			stmt.setString(1, c.getName());
			stmt.setDate(2, new Date(c.getDob().getTime()));
			stmt.setString(3, c.getContactDetails());
			
			int count = stmt.executeUpdate();
			
			if (count == 1) {
				System.out.println("Customer record updated successfully");
			}
		} catch (SQLException e) {
			throw new DataAccessException("Error " + e.getMessage(), e);
		} finally {
			releaseResources(conn, stmt, null);
		}


	}

}
