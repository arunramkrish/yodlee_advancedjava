package com.yodlee.jdbc;

import java.sql.SQLException;

public class ProductService {
	private IProductDao productDao;
	
	public void setProductDao(IProductDao productDao) {
		this.productDao = productDao;
	}
	
	public void createProduct(Product prod) {
		productDao.create(prod.getName(), prod.getPrice());
	}
	
	public Product getProduct(String name) throws SQLException {
		return productDao.getProduct(name);
	}
}
