package com.yodlee.jdbc;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.sql.DataSource;
import javax.xml.crypto.Data;

import org.apache.commons.dbcp.BasicDataSource;

public class PooledDatabaseUtil {
	private static Properties prop = new Properties();

	static {
		try {
			prop.load(ClassLoader.getSystemResourceAsStream("jdbc.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static String url = prop.getProperty("url");
	private static String user = prop.getProperty("user");
	private static String password = prop.getProperty("password");
	private static String driver = prop.getProperty("driver");
	private static int minIdle = Integer.parseInt(prop.getProperty("minIdle"));
	private static int maxIdle = Integer.parseInt(prop.getProperty("maxIdle"));
	
	static {
		try {
			Class.forName(driver);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}
	private static DataSource datasource = null;
	
	public static Connection getConnection() throws SQLException {
		if (datasource == null) {
			datasource = new BasicDataSource();
			((BasicDataSource)datasource).setUrl(url);
			((BasicDataSource)datasource).setUsername(user);
			((BasicDataSource)datasource).setPassword(password);
			((BasicDataSource)datasource).setDriverClassName(driver);
			((BasicDataSource)datasource).setMinIdle(minIdle);
			((BasicDataSource)datasource).setMaxIdle(maxIdle);
			((BasicDataSource)datasource).setMaxActive(maxIdle);
		}
		
		return datasource.getConnection();
		
	}

	public static void releaseResources(Connection conn, Statement stmt,
			ResultSet rs) {
		try {
			if (rs != null) {
				rs.close();
			}
		} catch (Exception e) {

		}

		try {
			if (stmt != null) {
				stmt.close();
			}
		} catch (Exception e) {

		}

		try {
			if (conn != null) {
				conn.close();
			}
		} catch (Exception e) {

		}

	}
}
