package com.yodlee.jdbc;

import java.sql.SQLException;
import java.util.Map;

public interface IProductDao {
	public void create(String name, float price);

	public Map<String, Float> readProducts() throws Exception;

	public Product getProduct(String name) throws SQLException;

}
