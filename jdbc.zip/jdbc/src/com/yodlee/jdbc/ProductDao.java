package com.yodlee.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class ProductDao {
	public void create(String name, float price) {
		if ((name == null) || ("".equals(name))) {
			return;
		}
		
		Connection connection = null;
		PreparedStatement stmt = null;
		try {
			connection = PooledDatabaseUtil.getConnection();
			
			String sql = "INSERT INTO PRODUCT(name,price) values(?, ?)";
			
			stmt = connection.prepareStatement(sql);
//			stmt.setDate(4, new Date(new java.util.Date().getTime()));
			stmt.setString(1, name);
			stmt.setFloat(2, price);
			
			int rows = stmt.executeUpdate();
			
			System.out.println("inserted successfully" + rows);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			DatabaseUtil.releaseResources(connection, stmt, null);
		}
	}
	
	public Map<String, Float> readProducts()  throws Exception {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Map<String, Float> products = new HashMap<String, Float>();
		try {
			connection = PooledDatabaseUtil.getConnection();
			
			String sql = "SELECT name,price FROM PRODUCT";
			
			stmt = connection.prepareStatement(sql);
			
			rs = stmt.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString("name") + " " + rs.getFloat("price"));
				products.put(rs.getString("name"), rs.getFloat("price"));
			}
			
			System.out.println("fetched successfully");
			return products;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			DatabaseUtil.releaseResources(connection, stmt, rs);
		}
	}
	public static void main(String[] args) throws Exception {
		long time = System.currentTimeMillis();
		new ProductDao().create("prod1", 99.9F);
		System.out.println(System.currentTimeMillis() - time);
		
		time = System.currentTimeMillis();
		new ProductDao().create("prod2", 99.9F);
		new ProductDao().readProducts();
		System.out.println(System.currentTimeMillis() - time);
		
	}

	public Product getProduct(String name) throws SQLException {
		Connection connection = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		Map<String, Float> products = new HashMap<String, Float>();
		try {
			connection = PooledDatabaseUtil.getConnection();
			
			String sql = "SELECT name,price FROM PRODUCT where name = ?";
			
			stmt = connection.prepareStatement(sql);
			stmt.setString(1, name);
			
			rs = stmt.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getString("name") + " " + rs.getFloat("price"));
				Product prod = new Product();
				prod.setName(rs.getString("name"));
				prod.setPrice(rs.getFloat("price"));
				return prod;
			}
			
			System.out.println("fetched successfully");
		} catch (SQLException e) {
			e.printStackTrace();
			throw e;
		} finally {
			DatabaseUtil.releaseResources(connection, stmt, rs);
		}
		return null;
		
	}
}
