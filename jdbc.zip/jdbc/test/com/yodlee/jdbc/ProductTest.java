package com.yodlee.jdbc;

import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.Map;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

public class ProductTest {
	private static ProductDao productDao;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Setup before clas");
		productDao = new ProductDao();
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("tear down before clas");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("Setup ");
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("tear down");
	}

	@Test
	public void testCreate() {
		productDao.create("Laptop", 40000F);

		try {
			Map<String, Float> products = productDao.readProducts();
			assertEquals("Check price match", (Float) 40000F,
					products.get("Laptop"));
		} catch (Exception e) {
			fail("Unexpected exception received" + e.getMessage());
		}
	}

	@Test
	@Ignore
	public void testCreateNull() {
		productDao.create(null, 40000F);

		try {
			Map<String, Float> products = productDao.readProducts();
			assertNull("No null object", products.get(null));
		} catch (Exception e) {
			fail("Unexpected exception received" + e.getMessage());
		}

		
//		fail("Unexpected exception received" + e.getMessage());
	}

	@Test
	public void testReadProducts() {
		// fail("Not yet implemented");
	}

	@Test(timeout=500)
	
	public void testReadProductByName() {
		productDao.create("newProd", 40000F);
		
		Product prod = null;
		try {
			prod = productDao.getProduct("newProd");
		} catch (SQLException e) {
			fail("Unknown exception received " + e);
		}
		
		assertNotNull(prod);
		
		assertEquals("newProd", prod.getName());
	}
}
