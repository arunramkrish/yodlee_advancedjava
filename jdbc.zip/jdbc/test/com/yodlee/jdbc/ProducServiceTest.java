package com.yodlee.jdbc;

import static org.junit.Assert.*;

import java.sql.SQLException;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class ProducServiceTest {
	private static IProductDao productDao;
	private static ProductService productService;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		productDao = EasyMock.createStrictMock(IProductDao.class);
		productService = new ProductService();
		productService.setProductDao(productDao);
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testCreateProduct() {
		productDao.create("Mobile", 1000F);
		EasyMock.replay(productDao);
		
		Product p = new Product();
		p.setName("Mobile");
		p.setPrice(1000F);
		productService.createProduct(p);
	}

	@Test
	public void testGetProduct() {
		try {
			productDao.getProduct("Mobile");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		Product p = new Product();
		p.setName("Mobile");
		p.setPrice(1000F);
		EasyMock.expectLastCall().andReturn(p);
		EasyMock.replay(productDao);
		
		try {
			Product actual = productService.getProduct("Mobile");
			System.out.println(actual.getName());
			assertEquals(p.getPrice(), actual.getPrice());
		} catch (SQLException e) {
			fail("Unexpected exception " + e);
		}
	}

}
