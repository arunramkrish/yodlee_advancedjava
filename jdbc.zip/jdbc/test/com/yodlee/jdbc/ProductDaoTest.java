package com.yodlee.jdbc;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProductDaoTest {

	@Test
	public void testCreate() {
		fail("Not yet implemented");
		
		
	}

	@Test
	public void testReadProducts() {
//		fail("Not yet implemented");
	}

}
