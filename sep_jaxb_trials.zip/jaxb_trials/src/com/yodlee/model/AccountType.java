package com.yodlee.model;

public enum AccountType {
	SAVINGS, CURRENT, CREDIT
}
