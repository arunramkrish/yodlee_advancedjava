package com.yodlee.model;

public enum AccountStatus {
	ACTIVE, CLOSED, DORMANT, SUSPENDED;
}
