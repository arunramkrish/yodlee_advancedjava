package com.yodlee.xml.jaxb;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.yodlee.model.Account;
import com.yodlee.model.AccountStatus;
import com.yodlee.model.Customer;

public class XmlMarshaller {

	public static void main(String[] args) throws JAXBException {
//		JAXBContext context = JAXBContext.newInstance(Account.class);
		JAXBContext context = JAXBContext.newInstance("com.yodlee.model");
		
		Marshaller marshaller = context.createMarshaller();
		
		Account account = new Account();
		Customer customer = new Customer();
		customer.setId("123");
		account.setAccountNumber(System.currentTimeMillis());
		account.setStatus(AccountStatus.ACTIVE);
		account.setCustomer(customer);
		
		marshaller.marshal(account, new File("account.xml"));
		
	}

}
