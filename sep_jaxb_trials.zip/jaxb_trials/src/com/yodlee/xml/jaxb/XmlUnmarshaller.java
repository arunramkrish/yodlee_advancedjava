package com.yodlee.xml.jaxb;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.stream.StreamSource;

import com.yodlee.model.Account;

public class XmlUnmarshaller {

	public static void main(String[] args) throws JAXBException {
		JAXBContext context = JAXBContext.newInstance("com.yodlee.model");

		Unmarshaller unmarshaller = context.createUnmarshaller();

		JAXBElement<Account> elmt = unmarshaller.unmarshal(new StreamSource(new File("account.xml")), Account.class);
		Account account = elmt.getValue();
//		Account account = (Account) unmarshaller.unmarshal(new File(
//				"account.xml"));
		System.out.println(account.getAccountNumber() + " customer "
				+ account.getCustomer().getId());
	}

}
