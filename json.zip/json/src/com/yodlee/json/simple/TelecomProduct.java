package com.yodlee.json.simple;

public class TelecomProduct extends Product {

}
