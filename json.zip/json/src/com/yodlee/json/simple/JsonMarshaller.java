package com.yodlee.json.simple;

import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;

import javax.xml.datatype.DatatypeFactory;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class JsonMarshaller {

	public static void main(String[] args) throws JsonGenerationException,
			JsonMappingException, IOException {
		Product prod = new FmcgProduct();
		prod.setId(1L);
		prod.setInventory(new BigInteger("1000"));
		prod.setName("prod1");

		Order order = new Order();
		order.setProduct(prod);
		order.setId(1L);
		order.setOrderDate(new Date());

		order.setCustomer(new Customer());
		
		ObjectMapper mapper = new ObjectMapper();
//		mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
//		mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		mapper.writerWithDefaultPrettyPrinter().writeValue(new FileWriter("order.json"), order);
	}

}
