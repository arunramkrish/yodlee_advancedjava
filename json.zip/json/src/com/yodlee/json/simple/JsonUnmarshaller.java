package com.yodlee.json.simple;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUnmarshaller {

	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        
		mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		
		Order deserializedOrder = mapper.readValue(new File("order.json"), Order.class);
		
		System.out.println(deserializedOrder.getId());
		
		System.out.println(deserializedOrder.getProduct().getClass());
		
		System.out.println(deserializedOrder.getCatchAll().get("paymentMode"));
	}

}
