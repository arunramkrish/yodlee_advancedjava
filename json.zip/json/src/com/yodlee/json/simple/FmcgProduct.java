package com.yodlee.json.simple;

public class FmcgProduct extends Product {

}
