package com.yodlee.thread.pool;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import com.yodlee.jdbc.entity.Account;
import com.yodlee.thread.traditional.Buffer;
import com.yodlee.thread.traditional.CallableProducer;
import com.yodlee.thread.traditional.Consumer;
import com.yodlee.thread.traditional.Factory;
import com.yodlee.thread.traditional.Producer;
import com.yodlee.thread.traditional.QueueBuffer;
import com.yodlee.thread.traditional.account.AccountFactory;
import com.yodlee.thread.traditional.account.ProdConsumerApp;

public class PooledApp {

	public static void main(String[] args) throws FileNotFoundException, InterruptedException, ExecutionException {
		PrintWriter writer = new PrintWriter(new FileOutputStream("prodcons.txt"), true);
		Factory<Account> factory = new AccountFactory(writer);
		Buffer<Account> buffer = new QueueBuffer<Account>();
		
		ExecutorService svc = Executors.newFixedThreadPool(11);
		Future<String> future = svc.submit(new CallableProducer<Account>(factory, buffer));
		
		svc.submit(new Consumer<Account>(factory, buffer));
		svc.submit(new Consumer<Account>(factory, buffer));
		svc.submit(new Consumer<Account>(factory, buffer));
		svc.submit(new Consumer<Account>(factory, buffer));
		svc.submit(new Consumer<Account>(factory, buffer));
		svc.submit(new Consumer<Account>(factory, buffer));
		svc.submit(new Consumer<Account>(factory, buffer));
		svc.submit(new Consumer<Account>(factory, buffer));
		svc.submit(new Consumer<Account>(factory, buffer));
		svc.submit(new Consumer<Account>(factory, buffer));
		
		System.out.print("Enter to exit");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		writer.close();
		svc.shutdown();
		
		if (future.isDone()) {
			System.out.println("Last product " + future.get());
		}
		
		System.exit(1);
		

	}

}
