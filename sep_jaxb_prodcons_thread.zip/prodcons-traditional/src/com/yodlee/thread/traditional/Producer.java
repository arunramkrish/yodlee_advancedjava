package com.yodlee.thread.traditional;

import java.util.concurrent.CountDownLatch;

public class Producer<T> implements Runnable {
	private Factory<T> factory;
	private Buffer<T> buffer;
	private boolean active = true;
	private CountDownLatch latch;
	
	public Producer(Factory<T> factory, Buffer<T> buffer) {
		this.factory = factory;
		this.buffer = buffer;
	}

	@Override
	public void run() {
		Thread.currentThread().setName("PRODUCER");
		while (active) {
			if (latch != null) {
				latch.countDown();
			}
			try {
				this.buffer.add(factory.create());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
//			try {
//				Thread.sleep(10);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
		}
	}
	
	public void shutdown() {
		active = false;
	}

	public void setLatch(CountDownLatch latch) {
		this.latch = latch;
	}
	
}
