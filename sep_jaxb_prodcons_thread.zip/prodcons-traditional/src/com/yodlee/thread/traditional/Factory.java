package com.yodlee.thread.traditional;

public interface Factory<T> {
	T create();
	void process(T product);
}
