package com.yodlee.thread.traditional;

import java.util.ArrayList;
import java.util.List;

public class Buffer<T> {
	private List<T> mylist = new ArrayList<T>();

	public void add(T product) throws InterruptedException {
		synchronized (mylist) {
			System.out.println("Producing " + product);
			mylist.add(product);
			if (mylist.size() == 1) {
				mylist.notify();
			}
		}
	}

	public T remove() throws InterruptedException {
		synchronized (mylist) {
			if (mylist.size() == 0) {
				while (true) {

					try {
						mylist.wait();
						System.out.println("Consuming " + mylist.get(0));
						return mylist.remove(0);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			} else {
				System.out.println("Consuming " + mylist.get(0));
				return mylist.remove(0);
			}

		}
	}
}
