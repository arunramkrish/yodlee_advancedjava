package com.yodlee.thread.traditional;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.SynchronousQueue;

public class QueueBuffer<T> extends Buffer<T> {
	private BlockingQueue<T> mylist = new ArrayBlockingQueue<T>(100);

	public void add(T product) throws InterruptedException {
		System.out.println("Adding");
		mylist.put(product);
	}

	public T remove() throws InterruptedException {
		System.out.println("Removing");
		return mylist.take();
	}
}
