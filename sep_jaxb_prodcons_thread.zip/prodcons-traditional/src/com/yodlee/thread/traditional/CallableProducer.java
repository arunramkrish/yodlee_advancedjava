package com.yodlee.thread.traditional;

import java.util.concurrent.Callable;

public class CallableProducer<T> implements Callable<String> {
	private Factory<T> factory;
	private Buffer<T> buffer;
	private boolean active = true;
	
	public CallableProducer(Factory<T> factory, Buffer<T> buffer) {
		this.factory = factory;
		this.buffer = buffer;
	}

	@Override
	public String call() {
		Thread.currentThread().setName("PRODUCER");
		T obj = null;
		while (active) {
			obj = factory.create();
			try {
				this.buffer.add(obj);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return obj.toString();
	}
	
	public void shutdown() {
		active = false;
	}
	
}
