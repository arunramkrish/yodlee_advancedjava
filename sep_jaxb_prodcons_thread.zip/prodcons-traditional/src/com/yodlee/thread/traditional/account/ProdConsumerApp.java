package com.yodlee.thread.traditional.account;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.concurrent.CountDownLatch;

import com.yodlee.jdbc.entity.Account;
import com.yodlee.thread.traditional.Buffer;
import com.yodlee.thread.traditional.Consumer;
import com.yodlee.thread.traditional.Factory;
import com.yodlee.thread.traditional.Producer;
import com.yodlee.thread.traditional.QueueBuffer;

public class ProdConsumerApp {

	public static void main(String[] args) throws FileNotFoundException {
		PrintWriter writer = new PrintWriter(new FileOutputStream("prodcons.txt"), true);
		Factory<Account> factory = new AccountFactory(writer);
		Buffer<Account> buffer = new QueueBuffer<Account>();
		
		Producer<Account> accountProd = new Producer<Account>(factory, buffer);
		Consumer<Account> accountCons = new Consumer<Account>(factory, buffer);
		
		CountDownLatch latch = new CountDownLatch(10);
		accountProd.setLatch(latch);
		accountCons.setLatch(latch);
		
		new Thread(accountProd).start();
		new Thread(accountCons).start();
		
		System.out.print("Enter to exit");
		Scanner scanner = new Scanner(System.in);
		String input = scanner.nextLine();
		accountProd.shutdown();
		accountCons.shutdown();
		writer.close();
		
		System.exit(1);
	}

}
