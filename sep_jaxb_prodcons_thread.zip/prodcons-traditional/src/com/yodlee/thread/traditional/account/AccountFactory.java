package com.yodlee.thread.traditional.account;

import java.io.IOException;
import java.io.Writer;

import com.yodlee.jdbc.dao.AccountDao;
import com.yodlee.jdbc.entity.Account;
import com.yodlee.thread.traditional.Factory;

public class AccountFactory implements Factory<Account> {
	private static long counter = 1L;
	private Writer writer;
	private AccountDao accountDao = new AccountDao();
	
	public AccountFactory(Writer writer) {
		this.writer = writer;
	}
	
	@Override
	public Account create() {
		return new Account(String.valueOf(System.currentTimeMillis()), 
				"Name " + (counter++), Math.random()) ;
	}

	@Override
	public void process(Account product) {
		try {
			writer.write(product + "\n");
			accountDao.create(product);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
