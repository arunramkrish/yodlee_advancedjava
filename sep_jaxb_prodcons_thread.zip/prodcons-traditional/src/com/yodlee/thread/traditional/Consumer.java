package com.yodlee.thread.traditional;

import java.util.concurrent.CountDownLatch;

public class Consumer<T> implements Runnable {
	private Factory<T> factory;
	private Buffer<T> buffer;
	private boolean active = true;
	private CountDownLatch latch;
	
	public Consumer(Factory<T> factory, Buffer<T> buffer) {
		this.factory = factory;
		this.buffer = buffer;
	}

	@Override
	public void run() {
		Thread.currentThread().setName("CONSUMER");
		while (active) {
			if (latch != null) {
				try {
					latch.await();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			try {
				factory.process(this.buffer.remove());
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public void shutdown() {
		active = false;
	}

	public void setLatch(CountDownLatch latch) {
		this.latch = latch;
	}
	

}
