package com.yodlee.jdbc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.yodlee.jdbc.entity.Account;
import com.yodlee.jdbc.entity.BaseEntity;

public abstract class BaseDao<E extends BaseEntity<K>, K> {
	public static final String DRIVER = "org.hsqldb.jdbc.JDBCDriver";
	public static final String URL = "jdbc:hsqldb:hsql://localhost/xdb";
	public static final String USER = "SA";
	public static final String PASSWORD = "";

	static {
		try {
			// Step 1: Load the driver
			Class.forName(DRIVER);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public void create(E entity) {
		Connection conn = null;
		PreparedStatement stmt = null;
		try {
			// Step 2: Obtain connection
			conn = getConnection();

			conn.setAutoCommit(false);

			// Step 3: create statement
			// stmt = conn.createStatement();
			stmt = conn.prepareStatement(getInsertSql(),
					ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_UPDATABLE);
			populateParams(stmt, entity);

			// execute statement
			// int count = stmt.executeUpdate(getInsertSql(entity));
			int count = stmt.executeUpdate();

			conn.commit();

		} catch (SQLException e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} catch(Exception e) {
			e.printStackTrace();
		}finally {
			releaseResources(conn, stmt, null);
		}

	}

	protected Connection getConnection() throws SQLException {
		return DriverManager.getConnection(URL, USER, PASSWORD);
	}

	public void update(E entity) {
		assert (entity.getId() != null);

	}

	public E findById(K id) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		try {
			// Step 2: Obtain connection
			conn = getConnection();

			// Step 3: create statement
			stmt = getSelectByIdStmt(conn, id);

			// execute statement
			// int count = stmt.executeUpdate(getInsertSql(entity));
			rs = stmt.executeQuery();

			while (rs.next()) {
				E entity = createEntityFromResultSet(rs);
				return entity;
			}
			return null;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} finally {
			releaseResources(conn, stmt, rs);
		}

	}

	public E delete(K id) {
		return null;
	}

	public List<E> findAll() {
		return null;
	}

	protected abstract String getInsertSql();

	protected abstract void populateParams(PreparedStatement stmt, E entity)
			throws SQLException;

	protected abstract E createEntityFromResultSet(ResultSet rs)
			throws SQLException;

	protected abstract PreparedStatement getSelectByIdStmt(Connection conn, K id)
			throws SQLException;

	private void releaseResources(Connection conn, Statement stmt, ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}

		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if (conn != null) {
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}

}
