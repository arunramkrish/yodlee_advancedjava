package com.yodlee.jdbc.dao;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;

import com.yodlee.jdbc.entity.BaseEntity;

public abstract class BasePooledDao<T extends BaseEntity<P>, P> extends
		BaseDao<T, P> {
	private DataSource datasource = null;

	@Override
	protected synchronized Connection getConnection() throws SQLException {
		if (datasource == null) {
			try {
				datasource = new BasicDataSource();
			} catch (Exception e) {
				e.printStackTrace();
			}
			BasicDataSource bds = (BasicDataSource) datasource;
			bds.setUsername(USER);
			bds.setPassword(PASSWORD);
			bds.setUrl(URL);
			bds.setDriverClassName(DRIVER);

			// for the pool
			bds.setInitialSize(5);
			bds.setMinIdle(3);
			bds.setMaxIdle(5);
			bds.setMaxTotal(8);
			bds.setValidationQuery("select 1 from INFORMATION_SCHEMA.SYSTEM_USERS");
			bds.setMaxWaitMillis(1000);
		}
		System.out.println("Num idle " + Thread.currentThread().getName()
				+ ((BasicDataSource) datasource).getNumIdle());
		return datasource.getConnection();
	}

}
