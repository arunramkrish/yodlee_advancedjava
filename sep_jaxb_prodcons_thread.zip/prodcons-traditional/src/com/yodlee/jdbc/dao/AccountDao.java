package com.yodlee.jdbc.dao;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import com.yodlee.jdbc.entity.Account;

public class AccountDao extends BasePooledDao<Account, String> {

	@Override
	protected String getInsertSql() {
//		String insertStmt = "INSERT INTO ACCOUNTS (ACCOUNT_NUMBER, ACCOUNT_NAME, BALANCE) "
//				+ "VALUES ('"
//				+ entity.getAccountNumber()
//				+ "', '"
//				+ entity.getAccountName() + "', " + entity.getBalance() + ")";
		String insertStmt = "INSERT INTO ACCOUNTS (ACCOUNT_NUMBER, ACCOUNT_NAME, BALANCE) "
				+ "VALUES (?,?,?)";
		return insertStmt;
	}

	@Override
	protected void populateParams(PreparedStatement stmt, Account entity) throws SQLException {
//		stmt.setString(1, entity.getAccountNumber());
		stmt.setString(1, String.valueOf(System.currentTimeMillis() + Math.random()));
		stmt.setString(2, entity.getAccountName());
		stmt.setDouble(3, entity.getBalance());
	}

	@Override
	protected Account createEntityFromResultSet(ResultSet rs) throws SQLException {
		ResultSetMetaData metaData = rs.getMetaData();
//		metaData.getColumnType(column)
		Account account = new Account();
		account.setAccountNumber(rs.getString(1));
		account.setAccountName(rs.getString(2));
		
		return account;
	}

	@Override
	protected PreparedStatement getSelectByIdStmt(Connection conn, String id) throws SQLException {
		DatabaseMetaData metaData = conn.getMetaData();
//		metaData.get
		PreparedStatement stmt = conn.prepareStatement("SELECT ACCOUNT_NUMBER, ACCOUNT_NAME, BALANCE "
				+ "FROM ACCOUNTS WHERE ACCOUNT_NUMBER = ?");
		stmt.setString(1, id);
		
		return stmt;
	}

}
