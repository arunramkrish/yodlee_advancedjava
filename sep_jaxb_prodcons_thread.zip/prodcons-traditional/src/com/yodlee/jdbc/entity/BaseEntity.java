package com.yodlee.jdbc.entity;

public abstract class BaseEntity<K> {
	public abstract K getId();
}
