package com.yodlee.jdbc.entity;

public class Account extends BaseEntity<String> {
	private String accountNumber;
	private String accountName;
	private Double balance;
	public Account() {
		super();
	}
	public Account(String accountNumber, String accountName, Double balance) {
		super();
		this.accountNumber = accountNumber;
		this.accountName = accountName;
		this.balance = balance;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public Double getBalance() {
		return balance;
	}
	public void setBalance(Double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", accountName="
				+ accountName + ", balance=" + balance + "]";
	}
	@Override
	public String getId() {
		return accountNumber;
	}
}
