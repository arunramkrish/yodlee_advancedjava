package com.yodlee.stax.stream;

public enum Category {
    FICTION,
    PASCAL,
    PROGRAMMING
}
