package com.yodlee.stax;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.xml.namespace.QName;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.Attribute;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;

public class OrderEventReader {
	public static void main(String[] args) throws FileNotFoundException,
			XMLStreamException {
		XMLInputFactory xif = XMLInputFactory.newInstance();
		XMLEventReader eventReader = xif
				.createXMLEventReader(new FileInputStream("order.xml"));
		
		while (eventReader.hasNext()) {
			XMLEvent event = eventReader.nextEvent();
			
			if (event.isStartElement()) {
				StartElement element = event.asStartElement();
				
				if (element.getName().getLocalPart().equals("order")) {
					Attribute idAttr = element.getAttributeByName(new QName("id"));
					
					System.out.println("Order id: " + idAttr.getValue());
				}
				
				if (element.getName().getLocalPart().equals("name")) {
					event = eventReader.nextEvent();
					System.out.println("Product Name " + event.asCharacters().getData());
				}
			}
		}

	}
}
